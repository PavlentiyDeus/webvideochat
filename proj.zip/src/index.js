import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';

ReactDOM.render(
  <React.StrictMode>
    <App />
    <footer className={'flex-s-a'}> <p>Все права и обязанности сервиса вы можете посмотреть в   <a href="/policyconf"> политике
 конфеденциальности</a></p><p>Все права и обязанности клиентов вы можете посмотреть в   <a href="/policyclient">
 пользовательском соглашении</a></p><p>Информация о сайте доступна по ссылке  <a href="/manual">о сайте</a></p></footer>
  </React.StrictMode>,
  document.getElementById('root')
);
