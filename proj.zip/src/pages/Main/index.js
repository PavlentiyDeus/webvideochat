import {useState, useEffect, useRef} from 'react';
import socket from '../../socket';
import ACTIONS from '../../socket/actions';
import {useHistory} from 'react-router';
import {v4} from 'uuid';


export default function Main() {
 
  const history = useHistory();
  const [rooms, updateRooms] = useState([]);
  const rootNode = useRef();
  var i = 0;
  
  return (
    <div class='maindiv' ref={rootNode}>
    <img src="./img/actuallogotype2.png" alt="" style={{width: "200px",margin: "20px 40% !important"}} onClick={(e)=>{ i++; if(i==5){ history.push(`/sexx`);} }}/><i><b>AtMeetAdd</b></i>
       <div className={'flex-s-b'}>
       <button  className="butsex" onClick={() => {
        history.push(`/sexm`);
      }}>Мужчина</button>
      <button  className="butsex" onClick={() => {
        history.push(`/sexg`);
      }}>Женщина</button>
       </div>
{/* 
       <div>
         <h4>Шрифт Сentury Gothic </h4>
       <div class="li l1">
      <p><sup>Supstr</sup>Almost before we knew </p>
      <sub>стиль начертания:вес 900,растяжение ультра растянутое</sub>
    </div>
    <div class="li l2">
      <p><sup>Supstr</sup>Almost before we knew </p>
      <sub>стиль начертания:вес 600,растяжение нормальное</sub>
    </div>
    <div class="li l3">

      <p><sup>Supstr</sup> Almost before we knew </p>
      <sub>стиль начертания:вес 100,растяжение ультра растянутое</sub>
    </div>  
      </div>  */}
    </div>
  );
}