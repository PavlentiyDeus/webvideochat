import {useState, useEffect, useRef} from 'react';
import socket from '../../socket';
import ACTIONS from '../../socket/actions';
import {useHistory} from 'react-router';
import {v4} from 'uuid';

const imgarr = ['img1','img2','img3','img4','img5'];

export default function SexM() {
  const history = useHistory();
  const [rooms, updateRooms] = useState([]);
  const rootNode = useRef();
  
  useEffect(() => {
    socket.on(ACTIONS.SHARE_ROOMS, ({rooms = []} = {}) => {
      if (rootNode.current) {
        updateRooms(rooms);
      }
    });
  }, []);

  return (
    <div class='maindiv' ref={rootNode}>
      <h1>Доступные комнаты сервисы</h1>
      <img src="./img/actuallogotype2.png" alt="" style={{width: '150px',margin: '20px 10% !important'}}></img>
      


      <ul class='grid center' id="listrooms" >
        {
        rooms.map(roomID =>
          (
          <li className={imgarr[Math.floor(Math.random()*imgarr.length)]}
          // style={{background:}}
          
          key={roomID} >
            {roomID}
            <button  class="btn butlistrooms" onClick ={ () => {
              history.push(`/room/${roomID}`);
            }}>Подключиться</button>
          </li>
        ))
        }
        <li class="listlastelem"><button  class="btn center butpeer" onClick={() => {
        history.push(`/room/${v4()}`);
      }}>Создать комнату</button></li> 
      </ul>

      
    </div>
  );
}