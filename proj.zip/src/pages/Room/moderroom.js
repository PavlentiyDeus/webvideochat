import { LOCAL_VIDEO } from "../../hooks/useWebRTC";




export default function Room() {
    const {id: roomID} = useParams();
    const {clients, provideMediaRef} = useWebRTC(roomID);
    const videoLayout = layout(clients.length);
    const history = useHistory();
  
    socket.on('connect',function(){
      socket.on('eventClientmess',function(data){
        if(data.num===2)
        {
          document.querySelector('#messanger').innerHTML+='<li class="mymessanges"><sup>'+data.text+'<sup><sub>'+data.time+'<sub></li>';
        }
        else if(data.num===3)
        {
        document.querySelector('#messanger').innerHTML+='<li><div>'+data.text+'<sub>'+data.time+'<sub></div></li>';
        }
      });
      
    })
  
    return (
      <div className={'bonjourblock'} >
        <button class="btn2 round clickabled"  onClick={() => {
          history.push(`/`);}} >Выйти</button>
        {clients.map((clientID, index) => {
            if(clientID==LOCAL_VIDEO){}
            else{
          return (
            <div  key={clientID} style={videoLayout[index]} id={clientID}>
              <video class="streamdiv bonjour"
                width='100%'   height='100%'
                ref={instance => {
                  provideMediaRef(clientID, instance);
                }}
                autoPlay  playsInline
                muted={clientID === LOCAL_VIDEO}
              />           
              
            </div>
          );}
        })}
        <div id="blockmessanger">
        <div id="messanger">  </div>
        <input type='text' id='input'/>

        <input type='submit' id='send' value='Администратор:' onClick={function () {
         socket.emit('eventServermess',document.getElementById('input').value)
          document.getElementById('input').value='Администратор:';
        }} /></div>
      </div>
    );
  }